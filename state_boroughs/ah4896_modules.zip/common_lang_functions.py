import nltk
from nltk.metrics import *
import re

# Functions that are appliable to different types of language

def isNull(x):

    # Handle a row that is a true null
    if x is None or (isinstance(x,str) and x.lower() == 'n/a'):
        return True

    # Handle a row that is an ordinary blank
    return len(x) == 0

def checkTypo(b,l,threshold):

    # If the edit distance is less than 5, consider this a typo
    for x in l:
        if edit_distance(b,x) < threshold:
            return True

    return False

def checkSpacing(b,l):

    b_cleaned = b.strip()

    # Check if the value is valid but there are spacing issues
    if b_cleaned in l and b not in l:
        return True

    return False
